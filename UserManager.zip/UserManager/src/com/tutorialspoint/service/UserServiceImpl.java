package com.tutorialspoint.service;

import java.util.List;
//import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tutorialspoint.dao.DaoServiceImpl;
import com.tutorialspoint.model.User;



//@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{
	
	private static DaoServiceImpl daoService = null;
	

	public List<User> findAllUsers() 
	{
		if (daoService==null)
		{
			daoService = new DaoServiceImpl();
		}	
		
		return daoService.getAllTasks();
	}
	
	
	public boolean addUser(User user) {
		if (daoService==null)
		{
			daoService = new DaoServiceImpl();
		}	
		daoService.addUser(user);
		return true;
	}	
	
	
	public List<User> getUser(String name) {
		if (daoService==null)
		{
			daoService = new DaoServiceImpl();
		}			
		return daoService.getUser(name);
	}	
	
	
	public User getUser(int id) {
		if (daoService==null)
		{
			daoService = new DaoServiceImpl();
		}			
		return daoService.getUser(id);
	}	

	public void updateUser(User user) {
		if (daoService==null)
		{
			daoService = new DaoServiceImpl();
		}			
		daoService.updateUser(user);
	}

	public void deleteUserById(int id) {
		
		if (daoService==null)
		{
			daoService = new DaoServiceImpl();
		}	
		
		 daoService.deleteTask(id);
	}


}