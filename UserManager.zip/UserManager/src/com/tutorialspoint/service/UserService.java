package com.tutorialspoint.service;

import java.util.List;

import com.tutorialspoint.model.User;




public interface UserService {

	boolean addUser(User user);
	void updateUser(User user);
	List<User> findAllUsers(); 
	List<User> getUser(String name); 
	User getUser(int id);
	
}