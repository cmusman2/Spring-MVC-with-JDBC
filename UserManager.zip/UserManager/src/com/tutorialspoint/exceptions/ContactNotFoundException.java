package com.tutorialspoint.exceptions;

public class ContactNotFoundException extends Exception{
	
	private String msg;
	
	public ContactNotFoundException()
	{
		super();
	}
	
	public ContactNotFoundException(String m)
	{
		this.msg = System.currentTimeMillis()+":"+m;
	}
	
	public String getMsg()
	{
		return msg;
	}
}
