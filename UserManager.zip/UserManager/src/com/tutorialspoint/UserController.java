package com.tutorialspoint;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.tutorialspoint.model.User;
import com.tutorialspoint.service.UserService;
import com.tutorialspoint.service.UserServiceImpl;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;


@Controller
public class UserController {

	
	UserServiceImpl userService;  //Service which will do all data retrieval/manipulation work
 
	@Autowired
    @Qualifier("userValidator")
    private Validator validator;
 	
	@InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }	
	
	
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String root() {
        return "index";
    }	      
  
    
    @RequestMapping(value = "/do", method = RequestMethod.GET)
    public String root2(ModelMap model) {
    	model.addAttribute("mymsg","hello");
        return "do";
    }	
    
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public String delete(@RequestParam int id) {
    	if (userService==null)
    	{
       	 userService = new UserServiceImpl();    	 
    	}
    	userService.deleteUserById(id);
        return "redirect:/listUsers";
    }	    
    
    
    @RequestMapping(value = "/doAdd", method = RequestMethod.GET)
    public ModelAndView doAdd() {        
       
        return new ModelAndView("user", "userForm", new User());       

    }      
    
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(@ModelAttribute("userForm") @Validated User user, BindingResult bindingResult) {
    	ModelAndView modelView = new ModelAndView();
    	if (userService==null)
    	{
       	 userService = new UserServiceImpl();    	 
    	}
    	 if (bindingResult.hasErrors()) {    		
    		 /*for(FieldError field: bindingResult.getFieldErrors())
    		 {
    			 modelView.addObject(field.getCode(), field.toString());
    		 }*/
    		 modelView.addObject("user",user);
             return "user";
  
         } else {
        	 userService.addUser(user);
         }
    	
        return "redirect:/listUsers";
    }  
    
    @RequestMapping(value = "/doUpdate", method = RequestMethod.POST)
    public ModelAndView doUpdate(@RequestParam int id) {
    	if (userService==null)
    	{
       	 userService = new UserServiceImpl();    	 
    	}
    	
    	return new ModelAndView("update", "command", userService.getUser(id));
    }    
    
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(@ModelAttribute("userForm") User user, BindingResult bindingResult) {
    	if (userService==null)
    	{
       	 userService = new UserServiceImpl();    	 
    	}
    	userService.updateUser(user);    	
        return "redirect:/listUsers";
    } 
    
    
    @RequestMapping("/listUsers")
    public ModelAndView listUsers() {
     


    	if (userService==null)
    	 userService = new UserServiceImpl();
    	
        List<User> listUser = userService.findAllUsers();
        
        ModelAndView modelView = new ModelAndView("UserList");
        
        
        
        modelView.addObject("listUser", listUser);
     
        return modelView;
    }    
}