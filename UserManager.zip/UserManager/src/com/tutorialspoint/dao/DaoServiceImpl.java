package com.tutorialspoint.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tutorialspoint.model.User;


//@Service("daoService")
//@Transactional
public class DaoServiceImpl implements DaoService{

 private Connection connection;

 public DaoServiceImpl() {

	 
  connection = DBConnectionManager.getConnection();

 }
 
 @Override
 public List<User> getUser(String name)
 {
	 
	  List<User> users = new ArrayList<User>();

	 try {
		   Statement statement = connection.createStatement();	   		   
		   ResultSet rs = statement.executeQuery("select * from users where name like '%"+name+"'%'");		   
		   while (rs.next()) {

			   User user = new User();

			   user.setId(rs.getInt("id"));

			   user.setName(rs.getString("name"));

			   user.setAge(rs.getInt("age"));   
			   user.setSalary(rs.getBigDecimal("salary"));
			   users.add(user);
		   }
		  } catch (SQLException e) {

		   e.printStackTrace();

		  }
	 return users;
 }
 
 
 @Override
 public User getUser(int id)
 {
	 User user = new User();

	 try {
		   Statement statement = connection.createStatement();	   		   
		   ResultSet rs = statement.executeQuery("select * from users where id="+id);		   
		   while (rs.next()) {
			   user.setId(rs.getInt("id"));
			   user.setName(rs.getString("name"));
			   user.setAge(rs.getInt("age"));   
			   user.setSalary(rs.getBigDecimal("salary"));
		   }
		  } catch (SQLException e) {

		   e.printStackTrace();

		  }
	 return user;
 }
 
 
 @Override
 public boolean addUser(User user) {

  try {

   PreparedStatement preparedStatement = connection

 	   .prepareStatement("insert into users(name,age,salary) values (?, ?,?)");

   System.out.println("Task:"+user.getName());

   preparedStatement.setString(1, user.getName());

   preparedStatement.setInt(2, user.getAge());   
   preparedStatement.setBigDecimal(3, user.getSalary());  

   preparedStatement.executeUpdate();
   
   

  } catch (SQLException e) {

   e.printStackTrace();

  }
  return true;
 }
 

 
 @Override
 public void updateUser(User user) {

  try {

   PreparedStatement preparedStatement = connection

     .prepareStatement("update users set name=?, age=?, salary=? where id=?");
     
   preparedStatement.setString(1, user.getName());
   preparedStatement.setInt(2, user.getAge());
   preparedStatement.setBigDecimal(3, user.getSalary());
   
   preparedStatement.setLong(4, user.getId());

   preparedStatement.executeUpdate();

  } catch (SQLException e) {

   e.printStackTrace();

  }

 }
 
 
 @Override
 public void deleteTask(int taskId) {

	  try {

	   PreparedStatement preparedStatement = connection

	     .prepareStatement("delete from users where id=?");

	   // Parameters start with 1

	   preparedStatement.setInt(1, taskId);

	   preparedStatement.executeUpdate();

	  } catch (SQLException e) {

	   e.printStackTrace();

	  }

	 }
 
 
 


 @Override
 public List<User> getAllTasks() {

  List<User> tasks = new ArrayList<User>();

  try {

   Statement statement = connection.createStatement();

   ResultSet rs = statement.executeQuery("select * from users");

   while (rs.next()) {

	   User task = new User();

    task.setId(rs.getInt("id"));

    task.setName(rs.getString("name"));

    task.setAge(rs.getInt("age"));   
    task.setSalary(rs.getBigDecimal("salary"));


    tasks.add(task);

   }

  } catch (SQLException e) {

   e.printStackTrace();

  }

  return tasks;

 }

 
}