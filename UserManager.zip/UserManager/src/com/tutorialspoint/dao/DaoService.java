package com.tutorialspoint.dao;

import java.util.List;

import com.tutorialspoint.model.User;

public interface DaoService {
	 public boolean addUser(User user);
	 public void updateUser(User user);
	 public List<User> getAllTasks();
	 public List<User> getUser(String name);
	 public User getUser(int  id);	
	 public void deleteTask(int taskId);
	 
}
