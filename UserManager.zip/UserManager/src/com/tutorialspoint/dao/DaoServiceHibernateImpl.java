package com.tutorialspoint.dao;

import java.util.List;

import com.tutorialspoint.model.User;

public class DaoServiceHibernateImpl implements DaoService {

	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> getAllTasks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getUser(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUser(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTask(int taskId) {
		// TODO Auto-generated method stub
		
	}

}
